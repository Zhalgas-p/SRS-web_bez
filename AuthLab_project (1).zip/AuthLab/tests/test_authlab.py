import hashlib
import http.client
import re
import tempfile
import threading
import time
import unittest
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import urlencode

import authlab


class AuthLabSecurityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original_iterations = authlab.PBKDF2_ITERATIONS
        authlab.PBKDF2_ITERATIONS = 2_000
        authlab.DUMMY_HASH = hashlib.pbkdf2_hmac(
            "sha256", b"not-a-real-password", authlab.DUMMY_SALT, authlab.PBKDF2_ITERATIONS
        )

    @classmethod
    def tearDownClass(cls):
        authlab.PBKDF2_ITERATIONS = cls.original_iterations
        authlab.DUMMY_HASH = hashlib.pbkdf2_hmac(
            "sha256", b"not-a-real-password", authlab.DUMMY_SALT, authlab.PBKDF2_ITERATIONS
        )

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_db = authlab.DB_PATH
        authlab.DB_PATH = Path(self.tmp.name) / "test.sqlite3"
        authlab.COOKIE_SECURE = False
        authlab.init_db()
        authlab.add_user("alice", "student", "AlicePass!2026")
        authlab.add_user("bob", "student", "BobPass!2026")
        authlab.add_user("teacher", "teacher", "TeacherPass!2026")
        self.server = authlab.ThreadingHTTPServer(("127.0.0.1", 0), authlab.AuthLabHandler)
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        authlab.DB_PATH = self.old_db
        authlab.COOKIE_SECURE = False
        self.tmp.cleanup()

    def request(self, path, method="GET", data=None, cookies=None, extra_headers=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        headers = dict(extra_headers or {})
        if cookies:
            headers["Cookie"] = "; ".join(f"{key}={value}" for key, value in cookies.items())
        body = None
        if data is not None:
            body = urlencode(data)
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        conn.request(method, path, body=body, headers=headers)
        response = conn.getresponse()
        payload = response.read().decode("utf-8", errors="replace")
        raw_headers = response.getheaders()
        result_headers = dict(raw_headers)
        set_cookie_values = [value for name, value in raw_headers if name.lower() == "set-cookie"]
        if set_cookie_values:
            result_headers["Set-Cookie"] = "\n".join(set_cookie_values)
        result = (response.status, result_headers, payload)
        conn.close()
        return result

    @staticmethod
    def cookies_from(headers):
        result = {}
        for name, value in headers.items():
            if name.lower() == "set-cookie":
                for cookie_line in value.splitlines():
                    jar = SimpleCookie()
                    jar.load(cookie_line)
                    for key, morsel in jar.items():
                        result[key] = morsel.value
        return result

    @staticmethod
    def csrf_from(document):
        match = re.search(r'name="csrf_token" value="([^"]+)"', document)
        if not match:
            raise AssertionError("CSRF token was not found in the HTML page")
        return match.group(1)

    def get_login_state(self):
        status, headers, body = self.request("/login")
        self.assertEqual(status, 200)
        return self.cookies_from(headers), self.csrf_from(body), body

    def login(self, username="alice", password="AlicePass!2026"):
        cookies, csrf, _ = self.get_login_state()
        status, headers, body = self.request(
            "/login", "POST", {"username": username, "password": password, "csrf_token": csrf}, cookies
        )
        combined = dict(cookies)
        combined.update(self.cookies_from(headers))
        return status, headers, body, combined

    def get_csrf_for_session(self, cookies):
        status, _, body = self.request("/dashboard", cookies=cookies)
        self.assertEqual(status, 200)
        return self.csrf_from(body), body

    def test_01_anonymous_user_is_redirected_to_login(self):
        status, headers, _ = self.request("/dashboard")
        self.assertEqual(status, 303)
        self.assertEqual(headers.get("Location"), "/login")

    def test_02_password_is_stored_as_pbkdf2_hash_not_plaintext(self):
        with authlab.db_connect() as conn:
            row = conn.execute("SELECT password_hash, salt FROM users WHERE username='alice'").fetchone()
        self.assertNotEqual(row["password_hash"], "AlicePass!2026")
        expected = hashlib.pbkdf2_hmac("sha256", b"AlicePass!2026", bytes.fromhex(row["salt"]), 2_000).hex()
        self.assertEqual(row["password_hash"], expected)

    def test_03_wrong_password_returns_generic_401(self):
        cookies, csrf, _ = self.get_login_state()
        status, _, body = self.request("/login", "POST", {"username": "alice", "password": "incorrect", "csrf_token": csrf}, cookies)
        self.assertEqual(status, 401)
        self.assertIn("Логин немесе құпиясөз қате", body)

    def test_04_login_without_csrf_token_is_rejected(self):
        status, _, _ = self.request("/login", "POST", {"username": "alice", "password": "AlicePass!2026"})
        self.assertEqual(status, 403)

    def test_05_session_cookie_has_httponly_and_samesite(self):
        status, headers, _, _ = self.login()
        self.assertEqual(status, 303)
        set_cookie = headers.get("Set-Cookie", "")
        self.assertIn("HttpOnly", set_cookie)
        self.assertIn("SameSite=Lax", set_cookie)

    def test_06_login_rotates_prelogin_token_and_old_token_is_not_a_session(self):
        pre_cookies, _, _ = self.get_login_state()
        old_prelogin = pre_cookies["authlab_prelogin"]
        status, _, _, login_cookies = self.login()
        self.assertEqual(status, 303)
        self.assertNotEqual(login_cookies.get("authlab_session"), old_prelogin)
        status, headers, _ = self.request("/dashboard", cookies={"authlab_prelogin": old_prelogin})
        self.assertEqual(status, 303)
        self.assertEqual(headers.get("Location"), "/login")

    def test_07_student_cannot_open_admin_but_teacher_can(self):
        student_status, _, _, student_cookies = self.login("alice", "AlicePass!2026")
        self.assertEqual(student_status, 303)
        status, _, _ = self.request("/admin/users", cookies=student_cookies)
        self.assertEqual(status, 403)
        teacher_status, _, _, teacher_cookies = self.login("teacher", "TeacherPass!2026")
        self.assertEqual(teacher_status, 303)
        status, _, body = self.request("/admin/users", cookies=teacher_cookies)
        self.assertEqual(status, 200)
        self.assertIn("Тіркелген аккаунттар", body)

    def test_08_user_cannot_read_another_users_note(self):
        with authlab.db_connect() as conn:
            alice_id = conn.execute("SELECT id FROM users WHERE username='alice'").fetchone()["id"]
            cur = conn.execute("INSERT INTO notes(owner_id,title,body,created_at) VALUES(?,?,?,?)", (alice_id, "Alice private", "secret", time.time()))
            note_id = cur.lastrowid
        _, _, _, bob_cookies = self.login("bob", "BobPass!2026")
        status, _, _ = self.request(f"/notes/{note_id}", cookies=bob_cookies)
        self.assertEqual(status, 404)

    def test_09_create_note_requires_csrf_then_accepts_valid_token(self):
        status, _, _, cookies = self.login()
        self.assertEqual(status, 303)
        csrf, _ = self.get_csrf_for_session(cookies)
        status, _, _ = self.request("/notes/create", "POST", {"title": "Test", "body": "Body"}, cookies)
        self.assertEqual(status, 403)
        status, headers, _ = self.request("/notes/create", "POST", {"title": "Test", "body": "Body", "csrf_token": csrf}, cookies)
        self.assertEqual(status, 303)
        self.assertEqual(headers.get("Location"), "/dashboard")

    def test_10_logout_invalidates_old_session_cookie(self):
        status, _, _, cookies = self.login()
        self.assertEqual(status, 303)
        csrf, _ = self.get_csrf_for_session(cookies)
        status, _, _ = self.request("/logout", "POST", {"csrf_token": csrf}, cookies)
        self.assertEqual(status, 303)
        status, headers, _ = self.request("/dashboard", cookies={"authlab_session": cookies["authlab_session"]})
        self.assertEqual(status, 303)
        self.assertEqual(headers.get("Location"), "/login")

    def test_11_idle_timeout_expires_after_twenty_minutes(self):
        status, _, _, cookies = self.login()
        self.assertEqual(status, 303)
        with authlab.db_connect() as conn:
            conn.execute("UPDATE sessions SET last_seen=? WHERE token_hash=?", (time.time() - authlab.IDLE_TIMEOUT_SECONDS - 5, authlab.token_digest(cookies["authlab_session"])))
        status, _, _ = self.request("/dashboard", cookies=cookies)
        self.assertEqual(status, 303)

    def test_12_absolute_timeout_expires_after_four_hours(self):
        status, _, _, cookies = self.login()
        self.assertEqual(status, 303)
        with authlab.db_connect() as conn:
            conn.execute("UPDATE sessions SET created_at=? WHERE token_hash=?", (time.time() - authlab.ABSOLUTE_TIMEOUT_SECONDS - 5, authlab.token_digest(cookies["authlab_session"])))
        status, _, _ = self.request("/dashboard", cookies=cookies)
        self.assertEqual(status, 303)

    def test_13_user_html_is_escaped_before_rendering(self):
        status, _, _, cookies = self.login()
        self.assertEqual(status, 303)
        csrf, _ = self.get_csrf_for_session(cookies)
        status, _, _ = self.request("/notes/create", "POST", {"title": "<script>alert(1)</script>", "body": "<b>not html</b>", "csrf_token": csrf}, cookies)
        self.assertEqual(status, 303)
        _, _, body = self.request("/dashboard", cookies=cookies)
        self.assertIn("&lt;script&gt;", body)
        self.assertNotIn("<script>alert(1)</script>", body)

    def test_14_five_failed_passwords_trigger_temporary_lock(self):
        cookies, csrf, _ = self.get_login_state()
        for _ in range(authlab.LOGIN_FAILURE_LIMIT):
            status, _, _ = self.request("/login", "POST", {"username": "alice", "password": "wrong-pass", "csrf_token": csrf}, cookies)
            self.assertEqual(status, 401)
        status, _, body = self.request("/login", "POST", {"username": "alice", "password": "AlicePass!2026", "csrf_token": csrf}, cookies)
        self.assertEqual(status, 401)
        self.assertIn("Логин немесе құпиясөз қате", body)

    def test_15_sql_injection_like_login_input_does_not_bypass_auth(self):
        cookies, csrf, _ = self.get_login_state()
        status, _, _ = self.request("/login", "POST", {"username": "' OR 1=1 --", "password": "anything", "csrf_token": csrf}, cookies)
        self.assertEqual(status, 401)

    def test_16_security_response_headers_are_present(self):
        status, headers, _ = self.request("/login")
        self.assertEqual(status, 200)
        lower = {key.lower(): value for key, value in headers.items()}
        self.assertIn("content-security-policy", lower)
        self.assertIn("no-store", lower.get("cache-control", ""))
        self.assertEqual(lower.get("x-content-type-options"), "nosniff")

    def test_17_https_cookie_mode_uses_secure_and_host_prefix(self):
        authlab.COOKIE_SECURE = True
        try:
            status, headers, _ = self.request("/login")
            self.assertEqual(status, 200)
            set_cookie = headers.get("Set-Cookie", "")
            self.assertIn("__Host-authlab_prelogin=", set_cookie)
            self.assertIn("Secure", set_cookie)
            self.assertIn("Path=/", set_cookie)
        finally:
            authlab.COOKIE_SECURE = False


if __name__ == "__main__":
    unittest.main(verbosity=2)

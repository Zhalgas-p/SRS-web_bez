@echo off
cd /d "%~dp0"
echo Starting AuthLab on http://127.0.0.1:8000/login
echo Keep this window open while using the website.
py authlab.py serve
if errorlevel 1 (
  echo.
  echo If the Python launcher "py" is unavailable, run: python authlab.py serve
  pause
)

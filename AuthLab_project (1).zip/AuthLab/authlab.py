#!/usr/bin/env python3
"""AuthLab — local educational web app for authentication and session security.

Uses only the Python standard library. The server binds to 127.0.0.1 only.
This project is an educational prototype, not a production deployment template.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import hmac
import html
import os
import re
import secrets
import sqlite3
import sys
import time
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs
from getpass import getpass

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "authlab.sqlite3"
STATIC_DIR = BASE_DIR / "static"
PBKDF2_ITERATIONS = 600_000
IDLE_TIMEOUT_SECONDS = 20 * 60
ABSOLUTE_TIMEOUT_SECONDS = 4 * 60 * 60
PRELOGIN_TIMEOUT_SECONDS = 10 * 60
LOGIN_FAILURE_LIMIT = 5
LOGIN_LOCK_SECONDS = 5 * 60
MAX_BODY_BYTES = 32_768
COOKIE_SECURE = os.environ.get("AUTHLAB_HTTPS", "0") == "1"
DUMMY_SALT = b"AuthLab-dummy-salt-2026"
DUMMY_HASH = hashlib.pbkdf2_hmac("sha256", b"not-a-real-password", DUMMY_SALT, PBKDF2_ITERATIONS)

USERNAME_RE = re.compile(r"^[a-zA-Z0-9_.-]{3,32}$")


@contextmanager
def db_connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with db_connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                role TEXT NOT NULL CHECK (role IN ('student', 'teacher')),
                created_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                csrf_token TEXT NOT NULL,
                created_at REAL NOT NULL,
                last_seen REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS prelogins (
                token_hash TEXT PRIMARY KEY,
                csrf_token TEXT NOT NULL,
                expires_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                body TEXT NOT NULL,
                created_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS login_failures (
                username TEXT PRIMARY KEY COLLATE NOCASE,
                failed_count INTEGER NOT NULL,
                window_started REAL NOT NULL,
                locked_until REAL NOT NULL DEFAULT 0
            );
            """
        )


def hash_password(password: str, salt: bytes | None = None) -> tuple[str, str]:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return digest.hex(), salt.hex()


def verify_password(password: str, salt_hex: str, expected_hash: str) -> bool:
    try:
        salt = bytes.fromhex(salt_hex)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS).hex()
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(actual, expected_hash)


def add_user(username: str, role: str, password: str) -> None:
    username = username.strip()
    if not USERNAME_RE.fullmatch(username):
        raise ValueError("Логин 3–32 таңбадан тұруы керек; тек әріп, сан, _, -, . қолданыңыз.")
    if role not in ("student", "teacher"):
        raise ValueError("Рөл student немесе teacher болуы керек.")
    if len(password) < 8:
        raise ValueError("Құпиясөз кемінде 8 таңбадан тұруы керек.")
    password_hash, salt = hash_password(password)
    with db_connect() as conn:
        conn.execute(
            "INSERT INTO users(username, password_hash, salt, role, created_at) VALUES (?, ?, ?, ?, ?)",
            (username, password_hash, salt, role, time.time()),
        )


def cookie_names() -> tuple[str, str]:
    if COOKIE_SECURE:
        return "__Host-authlab_session", "__Host-authlab_prelogin"
    return "authlab_session", "authlab_prelogin"


def cookie_header(name: str, value: str, *, max_age: int | None = None, clear: bool = False) -> str:
    parts = [f"{name}={value}", "Path=/", "HttpOnly", "SameSite=Lax"]
    if COOKIE_SECURE:
        parts.append("Secure")
    if max_age is not None:
        parts.append(f"Max-Age={max_age}")
    if clear:
        parts.append("Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    return "; ".join(parts)


def token_digest(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _e(value: object) -> str:
    return html.escape(str(value), quote=True)


def page_shell(title: str, content: str, *, page_class: str = "app-page", user: sqlite3.Row | None = None) -> str:
    username = _e(user["username"]) if user else "Қонақ"
    role_label = "Оқытушы" if user and user["role"] == "teacher" else "Студент" if user else "Оқу зертханасы"
    nav = ""
    if user:
        admin_link = '<a class="nav-link" href="/admin/users">Пайдаланушылар</a>' if user["role"] == "teacher" else ""
        nav = f"""
        <nav class="top-nav">
          <a class="brand" href="/dashboard"><span class="brand-mark">A</span><span>Auth<span class="brand-light">Lab</span></span></a>
          <div class="nav-right"><a class="nav-link" href="/dashboard">Басты бет</a>{admin_link}
            <span class="user-chip"><span class="avatar">{username[:1].upper()}</span><span><b>{username}</b><small>{role_label}</small></span></span>
            <form method="post" action="/logout" class="logout-form"><input type="hidden" name="csrf_token" value="{_e(user['csrf_token'])}"><button class="btn btn-ghost btn-small" type="submit">Шығу ↗</button></form>
          </div>
        </nav>"""
    else:
        nav = '<nav class="top-nav"><a class="brand" href="/login"><span class="brand-mark">A</span><span>Auth<span class="brand-light">Lab</span></span></a><span class="nav-caption">ҚАУІПСІЗ ВЕБ-ҚОСЫМША ЗЕРТХАНАСЫ</span></nav>'
    return f"""<!doctype html>
<html lang="kk"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{_e(title)} · AuthLab</title><link rel="stylesheet" href="/static/style.css"></head>
<body class="{_e(page_class)}"><div class="ambient ambient-one"></div><div class="ambient ambient-two"></div>
{nav}<main>{content}</main><footer class="site-footer"><span>AUTHLAB · ОҚУ ЖОБАСЫ</span><span>Аутентификация · Сессия · Қолжетімділікті бақылау</span></footer></body></html>"""


def login_page(csrf_token: str, error: str = "") -> str:
    error_box = f'<div class="alert alert-error">{_e(error)}</div>' if error else ""
    content = f"""
    <section class="login-layout">
      <div class="login-intro">
        <div class="eyebrow"><span class="pulse-dot"></span> WEB SECURITY LAB / 2026</div>
        <h1>Қауіпсіздік<br><em>бірінші</em> орыннан.</h1>
        <p class="intro-copy">Веб-қосымшадағы аутентификацияны, сессияларды және қол жеткізуді бақылауды тәжірибе жүзінде зерттеңіз.</p>
        <div class="feature-list">
          <div class="feature-item"><span class="feature-icon">01</span><span><b>Аутентификация</b><small>PBKDF2 арқылы парольді қорғау</small></span></div>
          <div class="feature-item"><span class="feature-icon">02</span><span><b>Сессия қауіпсіздігі</b><small>HttpOnly cookie және таймаут</small></span></div>
          <div class="feature-item"><span class="feature-icon">03</span><span><b>Қол жеткізуді бақылау</b><small>RBAC, CSRF және IDOR қорғанысы</small></span></div>
        </div>
        <div class="intro-foot"><span class="mini-shield">◇</span> Тек жергілікті оқу ортасы · 127.0.0.1</div>
      </div>
      <div class="login-card-wrap"><div class="login-card">
        <div class="card-kicker">ЖЕКЕ КАБИНЕТ</div><h2>Қош келдіңіз</h2><p class="card-subtitle">Жалғастыру үшін аккаунтыңызға кіріңіз.</p>
        {error_box}
        <form method="post" action="/login" class="form-stack">
          <input type="hidden" name="csrf_token" value="{_e(csrf_token)}">
          <label for="username">Логин</label><div class="input-wrap"><span class="input-icon">⌁</span><input id="username" name="username" autocomplete="username" placeholder="Мысалы, alice" required maxlength="32"></div>
          <label for="password">Құпиясөз</label><div class="input-wrap"><span class="input-icon">✳</span><input id="password" type="password" name="password" autocomplete="current-password" placeholder="Құпиясөзіңізді енгізіңіз" required></div>
          <button class="btn btn-primary btn-full" type="submit">Жүйеге кіру <span>→</span></button>
        </form>
        <div class="card-note"><span>ⓘ</span> Аккаунтты жүйе әкімшісі терминал арқылы тіркейді.</div>
      </div><div class="login-card-bottom">PROTECTED BY AUTH<span>·</span>LAB</div></div>
    </section>"""
    return page_shell("Жүйеге кіру", content, page_class="login-page")


def dashboard_page(user: sqlite3.Row, notes: list[sqlite3.Row], message: str = "") -> str:
    note_cards = "".join(
        f'''<a class="note-card" href="/notes/{int(note['id'])}"><div class="note-top"><span class="note-tag">ЖЕКЕ ЖАЗБА</span><span class="note-arrow">↗</span></div><h3>{_e(note['title'])}</h3><p>{_e(note['body'][:145])}{'…' if len(note['body']) > 145 else ''}</p><small>{time.strftime('%d.%m.%Y · %H:%M', time.localtime(note['created_at']))}</small></a>'''
        for note in notes
    ) or '<div class="empty-state"><span class="empty-icon">✧</span><b>Әзірге жазба жоқ</b><p>Алғашқы жеке жазбаңызды осы жерден жасаңыз.</p></div>'
    alert = f'<div class="alert alert-success">{_e(message)}</div>' if message else ""
    content = f"""
    <section class="dashboard-hero"><div><div class="eyebrow"><span class="pulse-dot"></span> AUTHENTICATED SESSION</div><h1>Қайырлы күн, <em>{_e(user['username'])}</em></h1><p>Жеке кеңістігіңізге қош келдіңіз. Қауіпсіз оқу жұмысы осы жерден жалғасады.</p></div><div class="hero-badge"><span class="badge-check">✓</span><span><b>Сессия белсенді</b><small>Қорғалған байланыс</small></span></div></section>
    {alert}
    <section class="stats-grid"><div class="stat-card"><span class="stat-label">СІЗДІҢ РӨЛІҢІЗ</span><strong>{'TEACHER' if user['role']=='teacher' else 'STUDENT'}</strong><small>RBAC рұқсат матрицасы</small></div><div class="stat-card"><span class="stat-label">ЖЕКЕ ЖАЗБАЛАР</span><strong>{len(notes):02d}</strong><small>Тек сізге қолжетімді</small></div><div class="stat-card"><span class="stat-label">СЕССИЯ ТАЙМАУТЫ</span><strong>20 <i>мин</i></strong><small>Белсенділік болмаған кезде</small></div><div class="stat-card stat-card-accent"><span class="stat-label">ҚОРҒАУ ҚАБАТЫ</span><strong>ACTIVE <span class="live-dot"></span></strong><small>CSRF · Cookie · Owner check</small></div></section>
    <section class="content-grid"><div class="section-heading"><div><div class="eyebrow">YOUR WORKSPACE</div><h2>Жеке жазбалар</h2></div><span class="section-count">{len(notes)} жазба</span></div>
      <div class="notes-grid">{note_cards}</div>
      <aside class="create-panel"><div class="panel-heading"><div><div class="eyebrow">QUICK NOTE</div><h2>Жаңа жазба</h2></div><span class="panel-plus">＋</span></div><p class="panel-copy">Жазбаңыз тек өз аккаунтыңызға тиесілі болады.</p>
        <form method="post" action="/notes/create" class="form-stack"><input type="hidden" name="csrf_token" value="{_e(user['csrf_token'])}"><label for="title">Тақырып</label><input class="text-input" id="title" name="title" placeholder="Жазба тақырыбы" maxlength="80" required><label for="body">Мәтін</label><textarea class="text-input" id="body" name="body" rows="4" placeholder="Ойыңызды жазыңыз…" maxlength="2000" required></textarea><button class="btn btn-primary btn-full" type="submit">Жазбаны сақтау <span>→</span></button></form>
      </aside>
    </section>"""
    return page_shell("Жеке кабинет", content, user=user)


def admin_page(user: sqlite3.Row, users: list[sqlite3.Row]) -> str:
    rows = "".join(
        f'<tr><td><span class="table-avatar">{_e(row["username"][:1].upper())}</span><b>{_e(row["username"])}</b></td><td><span class="role-pill {"role-teacher" if row["role"] == "teacher" else "role-student"}">{"Оқытушы" if row["role"] == "teacher" else "Студент"}</span></td><td>{time.strftime("%d.%m.%Y", time.localtime(row["created_at"]))}</td></tr>'
        for row in users
    )
    content = f"""
    <section class="dashboard-hero compact-hero"><div><div class="eyebrow"><span class="pulse-dot"></span> TEACHER ACCESS / RBAC</div><h1>Пайдаланушылар <em>тізімі</em></h1><p>Бұл бөлім тек teacher рөліне қолжетімді.</p></div><div class="hero-badge"><span class="badge-check">✓</span><span><b>Рұқсат берілді</b><small>Серверлік тексеріс</small></span></div></section>
    <section class="table-panel"><div class="panel-heading"><div><div class="eyebrow">USER DIRECTORY</div><h2>Тіркелген аккаунттар</h2></div><span class="section-count">{len(users)} пайдаланушы</span></div><div class="table-scroll"><table><thead><tr><th>ПАЙДАЛАНУШЫ</th><th>РӨЛ</th><th>ТІРКЕЛГЕН КҮНІ</th></tr></thead><tbody>{rows}</tbody></table></div><p class="table-footnote">Рөлдер браузерден өзгертілмейді. Аккаунттарды әкімші терминал арқылы қосады.</p></section>"""
    return page_shell("Пайдаланушылар", content, user=user)


def simple_message_page(title: str, message: str, status: int, back: str = "/login") -> str:
    content = f'''<section class="message-card"><div class="message-symbol">{"403" if status == 403 else "404" if status == 404 else "!"}</div><div class="eyebrow">AUTHLAB / RESPONSE {status}</div><h1>{_e(title)}</h1><p>{_e(message)}</p><a class="btn btn-primary" href="{_e(back)}">Артқа қайту <span>→</span></a></section>'''
    return page_shell(title, content, page_class="message-page")


class AuthLabHandler(BaseHTTPRequestHandler):
    server_version = "AuthLab/1.0"
    sys_version = ""

    def log_message(self, fmt: str, *args: object) -> None:
        sys.stdout.write("[AuthLab] " + (fmt % args) + "\n")

    def _security_headers(self) -> None:
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; img-src 'self' data:; form-action 'self'; base-uri 'self'; frame-ancestors 'none'; object-src 'none'")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Pragma", "no-cache")

    def _send_html(self, status: int, document: str, extra_headers: list[tuple[str, str]] | None = None) -> None:
        payload = document.encode("utf-8")
        self.send_response(status)
        self._security_headers()
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        for name, value in extra_headers or []:
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(payload)

    def _redirect(self, location: str, extra_headers: list[tuple[str, str]] | None = None) -> None:
        self.send_response(303)
        self._security_headers()
        self.send_header("Location", location)
        for name, value in extra_headers or []:
            self.send_header(name, value)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _cookies(self) -> SimpleCookie:
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
        except Exception:
            return SimpleCookie()
        return cookie

    def _cookie_value(self, name: str) -> str | None:
        morsel = self._cookies().get(name)
        return morsel.value if morsel else None

    def _read_form(self) -> dict[str, str] | None:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return None
        if length < 0 or length > MAX_BODY_BYTES:
            return None
        raw = self.rfile.read(length).decode("utf-8", errors="replace")
        parsed = parse_qs(raw, keep_blank_values=True, max_num_fields=30)
        return {key: values[0] for key, values in parsed.items()}

    def _new_prelogin(self) -> tuple[str, str]:
        token = secrets.token_urlsafe(32)
        csrf = secrets.token_urlsafe(32)
        now = time.time()
        with db_connect() as conn:
            conn.execute("DELETE FROM prelogins WHERE expires_at < ?", (now,))
            conn.execute("INSERT INTO prelogins(token_hash, csrf_token, expires_at) VALUES (?, ?, ?)",
                         (token_digest(token), csrf, now + PRELOGIN_TIMEOUT_SECONDS))
        return token, csrf

    def _get_prelogin(self) -> sqlite3.Row | None:
        _, prelogin_name = cookie_names()
        token = self._cookie_value(prelogin_name)
        if not token:
            return None
        with db_connect() as conn:
            row = conn.execute("SELECT * FROM prelogins WHERE token_hash = ? AND expires_at > ?",
                               (token_digest(token), time.time())).fetchone()
        return row

    def _get_session(self) -> sqlite3.Row | None:
        session_name, _ = cookie_names()
        token = self._cookie_value(session_name)
        if not token:
            return None
        digest = token_digest(token)
        now = time.time()
        with db_connect() as conn:
            row = conn.execute(
                "SELECT s.*, u.id AS user_id, u.username, u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash = ?",
                (digest,),
            ).fetchone()
            if not row:
                return None
            if now - row["last_seen"] > IDLE_TIMEOUT_SECONDS or now - row["created_at"] > ABSOLUTE_TIMEOUT_SECONDS:
                conn.execute("DELETE FROM sessions WHERE token_hash = ?", (digest,))
                return None
            conn.execute("UPDATE sessions SET last_seen = ? WHERE token_hash = ?", (now, digest))
            return conn.execute(
                "SELECT s.*, u.id AS user_id, u.username, u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash = ?",
                (digest,),
            ).fetchone()

    def _require_session(self, *, teacher: bool = False) -> sqlite3.Row | None:
        session = self._get_session()
        if session is None:
            self._redirect("/login")
            return None
        if teacher and session["role"] != "teacher":
            self._send_html(403, simple_message_page("Қолжетімділік жоқ", "Бұл бөлімге тек оқытушы кіре алады.", 403, "/dashboard"))
            return None
        return session

    def _csrf_ok(self, expected: str | None, supplied: str | None) -> bool:
        return bool(expected and supplied and secrets.compare_digest(expected, supplied))

    def do_GET(self) -> None:  # noqa: N802
        path = self.path.split("?", 1)[0]
        if path == "/static/style.css":
            try:
                payload = (STATIC_DIR / "style.css").read_bytes()
            except OSError:
                self.send_error(404)
                return
            self.send_response(200)
            self._security_headers()
            self.send_header("Content-Type", "text/css; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if path in ("/", "/login"):
            if self._get_session():
                self._redirect("/dashboard")
                return
            token, csrf = self._new_prelogin()
            _, prelogin_name = cookie_names()
            self._send_html(200, login_page(csrf), [("Set-Cookie", cookie_header(prelogin_name, token, max_age=PRELOGIN_TIMEOUT_SECONDS))])
            return

        if path == "/dashboard":
            session = self._require_session()
            if session is None:
                return
            with db_connect() as conn:
                notes = conn.execute("SELECT * FROM notes WHERE owner_id = ? ORDER BY created_at DESC", (session["user_id"],)).fetchall()
            self._send_html(200, dashboard_page(session, notes))
            return

        if path == "/admin/users":
            session = self._require_session(teacher=True)
            if session is None:
                return
            with db_connect() as conn:
                users = conn.execute("SELECT id, username, role, created_at FROM users ORDER BY username COLLATE NOCASE").fetchall()
            self._send_html(200, admin_page(session, users))
            return

        if path.startswith("/notes/"):
            session = self._require_session()
            if session is None:
                return
            raw_id = path.rsplit("/", 1)[-1]
            if not raw_id.isdigit():
                self._send_html(404, simple_message_page("Жазба табылмады", "Сұралған жазба жоқ немесе сізге тиесілі емес.", 404, "/dashboard"))
                return
            with db_connect() as conn:
                note = conn.execute("SELECT * FROM notes WHERE id = ? AND owner_id = ?", (int(raw_id), session["user_id"])).fetchone()
            if not note:
                self._send_html(404, simple_message_page("Жазба табылмады", "Сұралған жазба жоқ немесе сізге тиесілі емес.", 404, "/dashboard"))
                return
            content = f'''<section class="note-detail"><a class="back-link" href="/dashboard">← Жеке кабинетке</a><div class="eyebrow">PRIVATE NOTE / #{int(note['id'])}</div><h1>{_e(note['title'])}</h1><p class="note-detail-body">{_e(note['body'])}</p><small>Жасалған уақыты: {time.strftime('%d.%m.%Y · %H:%M', time.localtime(note['created_at']))}</small><div class="owner-check"><span>✓</span> Иесі тексерілді · owner_id = user_id</div></section>'''
            self._send_html(200, page_shell("Жеке жазба", content, user=session))
            return

        self._send_html(404, simple_message_page("Бет табылмады", "Мұндай мекенжай AuthLab ішінде жоқ.", 404, "/dashboard"))

    def do_POST(self) -> None:  # noqa: N802
        path = self.path.split("?", 1)[0]
        form = self._read_form()
        if form is None:
            self._send_html(400, simple_message_page("Сұраныс қатесі", "Форма деректері оқылмады.", 400))
            return

        if path == "/login":
            prelogin = self._get_prelogin()
            if not prelogin or not self._csrf_ok(prelogin["csrf_token"], form.get("csrf_token")):
                self._send_html(403, simple_message_page("CSRF тексерісі өтпеді", "Кіру формасының қорғаныс токені жарамсыз немесе мерзімі аяқталған.", 403, "/login"))
                return
            username = form.get("username", "").strip()
            password = form.get("password", "")
            with db_connect() as conn:
                lock = conn.execute("SELECT * FROM login_failures WHERE username = ?", (username,)).fetchone()
                user = conn.execute("SELECT * FROM users WHERE username = ? COLLATE NOCASE", (username,)).fetchone()
            locked = bool(lock and lock["locked_until"] > time.time())
            if user:
                password_ok = verify_password(password, user["salt"], user["password_hash"])
            else:
                dummy = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), DUMMY_SALT, PBKDF2_ITERATIONS)
                hmac.compare_digest(dummy, DUMMY_HASH)
                password_ok = False
            if locked or not user or not password_ok:
                now = time.time()
                with db_connect() as conn:
                    if not locked:
                        current = conn.execute("SELECT * FROM login_failures WHERE username = ?", (username,)).fetchone()
                        if current and now - current["window_started"] < LOGIN_LOCK_SECONDS:
                            count = current["failed_count"] + 1
                            started = current["window_started"]
                        else:
                            count, started = 1, now
                        locked_until = now + LOGIN_LOCK_SECONDS if count >= LOGIN_FAILURE_LIMIT else 0
                        conn.execute(
                            "INSERT INTO login_failures(username, failed_count, window_started, locked_until) VALUES (?, ?, ?, ?) "
                            "ON CONFLICT(username) DO UPDATE SET failed_count=excluded.failed_count, window_started=excluded.window_started, locked_until=excluded.locked_until",
                            (username, count, started, locked_until),
                        )
                self._send_html(401, login_page(prelogin["csrf_token"], "Логин немесе құпиясөз қате. Қайта тексеріп көріңіз."))
                return

            session_token = secrets.token_urlsafe(32)
            csrf_token = secrets.token_urlsafe(32)
            now = time.time()
            with db_connect() as conn:
                conn.execute("DELETE FROM sessions WHERE user_id = ? AND created_at < ?", (user["id"], now - ABSOLUTE_TIMEOUT_SECONDS))
                conn.execute("INSERT INTO sessions(token_hash, user_id, csrf_token, created_at, last_seen) VALUES (?, ?, ?, ?, ?)",
                             (token_digest(session_token), user["id"], csrf_token, now, now))
                conn.execute("DELETE FROM prelogins WHERE token_hash = ?", (self._cookie_value(cookie_names()[1]) and token_digest(self._cookie_value(cookie_names()[1])) or "",))
                conn.execute("DELETE FROM login_failures WHERE username = ?", (username,))
            session_name, prelogin_name = cookie_names()
            headers = [
                ("Set-Cookie", cookie_header(session_name, session_token, max_age=ABSOLUTE_TIMEOUT_SECONDS)),
                ("Set-Cookie", cookie_header(prelogin_name, "", max_age=0, clear=True)),
            ]
            self._redirect("/dashboard", headers)
            return

        if path == "/notes/create":
            session = self._get_session()
            if session is None:
                self._redirect("/login")
                return
            if not self._csrf_ok(session["csrf_token"], form.get("csrf_token")):
                self._send_html(403, simple_message_page("CSRF тексерісі өтпеді", "Жазбаны сақтау үшін жарамды CSRF-токен қажет.", 403, "/dashboard"))
                return
            title = form.get("title", "").strip()
            body = form.get("body", "").strip()
            if not title or not body or len(title) > 80 or len(body) > 2000:
                self._send_html(400, simple_message_page("Деректерді тексеріңіз", "Тақырып пен мәтін бос болмауы керек. Ұзындық шектеуін сақтаңыз.", 400, "/dashboard"))
                return
            with db_connect() as conn:
                conn.execute("INSERT INTO notes(owner_id, title, body, created_at) VALUES (?, ?, ?, ?)",
                             (session["user_id"], title, body, time.time()))
            self._redirect("/dashboard")
            return

        if path == "/logout":
            session = self._get_session()
            if session is None:
                self._redirect("/login")
                return
            if not self._csrf_ok(session["csrf_token"], form.get("csrf_token")):
                self._send_html(403, simple_message_page("CSRF тексерісі өтпеді", "Шығу сұранысының токені жарамсыз.", 403, "/dashboard"))
                return
            session_name, prelogin_name = cookie_names()
            token = self._cookie_value(session_name)
            with db_connect() as conn:
                if token:
                    conn.execute("DELETE FROM sessions WHERE token_hash = ?", (token_digest(token),))
            headers = [
                ("Set-Cookie", cookie_header(session_name, "", max_age=0, clear=True)),
                ("Set-Cookie", cookie_header(prelogin_name, "", max_age=0, clear=True)),
            ]
            self._redirect("/login", headers)
            return

        self._send_html(404, simple_message_page("Бет табылмады", "Бұл әрекет AuthLab ішінде жоқ.", 404, "/dashboard"))


def run_server(port: int = 8000) -> None:
    init_db()
    server = ThreadingHTTPServer(("127.0.0.1", port), AuthLabHandler)
    print("\n  AuthLab іске қосылды")
    print(f"  Сайт: http://127.0.0.1:{port}/login")
    print("  Сервер тек осы компьютерде қолжетімді (127.0.0.1).")
    print("  Тоқтату үшін Ctrl + C басыңыз.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nAuthLab тоқтатылды.")
    finally:
        server.server_close()


def main() -> int:
    parser = argparse.ArgumentParser(description="AuthLab — жергілікті оқу веб-қосымшасы")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init", help="SQLite дерекқорын дайындау")
    add_parser = sub.add_parser("add-user", help="Жаңа пайдаланушы қосу")
    add_parser.add_argument("--username", required=True)
    add_parser.add_argument("--role", required=True, choices=("student", "teacher"))
    serve_parser = sub.add_parser("serve", help="Жергілікті веб-серверді іске қосу")
    serve_parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()

    try:
        if args.command == "init":
            init_db()
            print(f"Дерекқор дайын: {DB_PATH}")
        elif args.command == "add-user":
            init_db()
            password = getpass("Құпиясөз: ")
            confirm = getpass("Құпиясөзді қайталаңыз: ")
            if password != confirm:
                print("Қате: құпиясөздер сәйкес емес.", file=sys.stderr)
                return 1
            add_user(args.username, args.role, password)
            print(f"Пайдаланушы қосылды: {args.username} ({args.role})")
        elif args.command == "serve":
            if not 1024 <= args.port <= 65535:
                print("Порт 1024–65535 аралығында болуы керек.", file=sys.stderr)
                return 1
            run_server(args.port)
    except sqlite3.IntegrityError:
        print("Қате: мұндай логин бұрын тіркелген.", file=sys.stderr)
        return 1
    except ValueError as exc:
        print(f"Қате: {exc}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"Сервер қатесі: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
